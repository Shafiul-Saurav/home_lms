@extends('backend.layouts.master')

@section('title', 'Room Type')

@push('backend_style')
    @include('backend.pages.common.style')
@endpush

@section('backend_content')
    <div class="row">
        <div class="col-12">
            <div class="page-header">
                <div>
                    <h1 class="page-title">Room Type</h1>
                </div>
                <div class="ms-auto pageheader-btn">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Room Type Edit</li>
                    </ol>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header border-bottom d-flex justify-content-between">
                    <h3 class="card-title">Update Room Type</h3>
                    <a href="{{ route('room_types.index') }}" class="btn btn-info"><i class="fa-solid fa-angles-left fa-fw"></i> Back</a>
                </div>
                <div class="card-body">
                    <form action="{{ route('room_types.update', $room_type->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-row">
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="title">Title</label>
                                    <input type="text" name="title" class="form-control @error('title')
                                        is-invalid
                                    @enderror" id="title"
                                        value="{{ $room_type->title }}" required>
                                    @error('title')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="occupancy">Occupancy</label>
                                    <input type="text" name="occupancy" class="form-control @error('occupancy')
                                        is-invalid
                                    @enderror" id="occupancy"
                                        value="{{ $room_type->occupancy }}" required>
                                    @error('occupancy')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="bed_type">Bed Type</label>
                                    <input type="text" name="bed_type" class="form-control @error('bed_type')
                                        is-invalid
                                    @enderror" id="bed_type"
                                        value="{{ $room_type->bed_type }}" required>
                                    @error('bed_type')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea name="description" id="summernote" class="form-control @error('description')
                                        is-invalid
                                    @enderror" id="description" cols="30" rows="5">{{ $room_type->description }}</textarea>
                                    @error('description')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="sm_image">Small Image <span class="text-danger">*</span></label>
                                    <input type="file" name="sm_image" class="dropify" data-default-file="{{ asset('uploads/room_types') }}/{{ $room_type->sm_image }}"
                                        data-max-width="400" data-show-errors="true"
                                        data-errors-position="outside" data-max-height="420"
                                        data-allowed-file-extensions="png jpg"/>
                                    @if ($errors->has('sm_image'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('sm_image') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="lg_image">Large Image <span class="text-danger">*</span></label>
                                    <input type="file" name="lg_image" class="dropify" data-default-file="{{ asset('uploads/room_types') }}/{{ $room_type->lg_image }}"
                                        data-max-width="740" data-show-errors="true"
                                        data-errors-position="outside" data-max-height="710"
                                        data-allowed-file-extensions="png jpg"/>
                                    @if ($errors->has('lg_image'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('lg_image') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-secondary" type="submit">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->
@endsection

@push('backend_script')
    @include('backend.pages.common.script')
@endpush
