@extends('backend.layouts.master')

@section('title', 'Room')

@push('backend_style')
    @include('backend.pages.common.style')
    <style>
        .multi_img {
            position: relative;
        }

        .remove_icon {
            position: absolute;
            top: 0;
            right: 1px;
            opacity: 0;
            z-index: 999;
        }
        .remove_icon .delete-image {
            width: 24px;
            height: 24px;
            line-height: 24px;
        }
        .remove_icon .delete-image i{
            font-size: 22px;
        }

        .multi_img:hover .remove_icon {
            opacity: 1;
            transition: all 0.5s ease;
        }

        .multi_img img {
            display: block;
            max-width: 100%;
            height: auto;
            transition: opacity 0.5s ease;
        }

        .multi_img img:hover {
            opacity: 0.5;
        }
    </style>
@endpush

@section('backend_content')
    <div class="row">
        <div class="col-12">
            <div class="page-header">
                <div>
                    <h1 class="page-title">Room</h1>
                </div>
                <div class="ms-auto pageheader-btn">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Room Edit</li>
                    </ol>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header border-bottom d-flex justify-content-between">
                    <h3 class="card-title">Update Room</h3>
                    <a href="{{ route('rooms.index') }}" class="btn btn-info"><i class="fa-solid fa-angles-left fa-fw"></i>
                        Back</a>
                </div>
                <div class="card-body">
                    <form action="{{ route('rooms.update', $room->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-row">
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="roomtype_id" class="form-label mb-3">Select Room Type</label>
                                    <select id="roomtype_id" name="roomtype_id"
                                        class="form-control select2 form-select select2-hidden-accessible
                                    @error('roomtype_id')
                                        is-invalid
                                    @enderror">
                                        <option selected>Choose a Room Type</option>
                                        @forelse ($room_types as $room_type)
                                            <option value="{{ $room_type->id }}"
                                                @if ($room->roomtype_id == $room_type->id) selected @endif>{{ $room_type->title }}
                                            </option>
                                        @empty
                                        @endforelse
                                    </select>
                                    @error('roomtype_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="title">Title</label>
                                    <input type="text" name="title"
                                        class="form-control @error('title')
                                        is-invalid
                                    @enderror"
                                        id="title" value="{{ $room->title }}" required>
                                    @error('title')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea name="description" id="summernote"
                                        class="form-control @error('description')
                                        is-invalid
                                    @enderror"
                                        id="description" cols="30" rows="5">{!! $room->description !!}</textarea>
                                    @error('description')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="image">Image</label>
                                    <input type="file" name="image" class="dropify"
                                        data-default-file="{{ asset('uploads/rooms') }}/{{ $room->image }}"
                                        data-height="200" data-max-width="400" data-max-height="420" data-show-errors="true"
                                        data-errors-position="outside" data-allowed-file-extensions="png jpg" />
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="multiple_image">Multiple Images</label>
                                    <div id="multipleImageFields">
                                        <div class="d-flex justify-content-between mb-2" id="multipleImageField0">
                                            <input type="file" name="multiple_image[]" class="form-control me-4" />
                                            <button type="button" class="btn btn-secondary addImageField">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <ul class="list-inline">
                                    @foreach ($room->roomImages as $roomImage)
                                        <li class="list-inline-item multi_img" id="room-image-{{ $roomImage->id }}">
                                            <img src="{{ asset('uploads/rooms/' . $roomImage->multiple_image) }}"
                                                alt="" style="height: 95px">
                                            <div class="remove_icon">
                                                <button type="button"
                                                    class="btn-outline-warning border show_confirm delete-image p-0"
                                                    data-id="{{ $roomImage->id }}" data-toggle="tooltip"
                                                    data-placement="top" data-bs-original-title="Delete">
                                                    <i class="fa-regular fa-circle-xmark"></i>
                                                </button>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>


                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="price">Price</label>
                                    <input type="number" name="price"
                                        class="form-control @error('price')
                                        is-invalid
                                    @enderror"
                                        id="price" value="{{ $room->price }}" required>
                                    @error('price')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-secondary" type="submit">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->
@endsection

@push('backend_script')
    @include('backend.pages.common.script')
    <script>
        $(document).ready(function() {
            let imageFieldIndex = 1;

            // Add new image input field
            $(document).on('click', '.addImageField', function() {
                const newField = `
                    <div class="d-flex justify-content-between mb-2" id="multipleImageField${imageFieldIndex}">
                        <input type="file" name="multiple_image[]" class="form-control me-4" />
                        <button type="button" class="btn btn-danger removeImageField" data-id="${imageFieldIndex}">-</button>
                    </div>`;
                $('#multipleImageFields').append(newField);
                imageFieldIndex++;
            });

            // Remove image input field
            $(document).on('click', '.removeImageField', function() {
                const id = $(this).data('id');
                $(`#multipleImageField${id}`).remove();
            });
        });
    </script>
    <script>
        var drEvent = $('.dropify').dropify();

        drEvent.on('dropify.error.fileSize', function(event, element) {
            // alert('Filesize error message!');
        });
        drEvent.on('dropify.error.minWidth', function(event, element) {
            // alert('Min width error message!');
        });
        drEvent.on('dropify.error.maxWidth', function(event, element) {
            // alert('Max width error message!');
        });
        drEvent.on('dropify.error.minHeight', function(event, element) {
            // alert('Min height error message!');
        });
        drEvent.on('dropify.error.maxHeight', function(event, element) {
            // alert('Max height error message!');
        });
        drEvent.on('dropify.error.imageFormat', function(event, element) {
            // alert('Image format error message!');
        });
    </script>
    <script>
        $(document).on('click', '.delete-image', function(e) {
            e.preventDefault();

            var imageId = $(this).data('id');
            var url = '{{ route('room.image.delete', ':id') }}';
            url = url.replace(':id', imageId);

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            // Remove the image element from the page
                            $('#room-image-' + imageId).remove();
                            Swal.fire(
                                'Deleted!',
                                'Your image has been deleted.',
                                'success'
                            );
                        },
                        error: function(xhr) {
                            console.error(xhr.responseText);
                            Swal.fire(
                                'Error!',
                                'Something went wrong. Please try again.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    </script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
@endpush
